clear; clc;
mkdir('Results');
isOctave = exist('OCTAVE_VERSION', 'builtin') ~= 0;

% Obtaining results for Interface 1
database_P1.trainingMacs    = dlmread('Databases/uminhopiepreal_int01_trainrss.csv');
database_P1.testMacs        = dlmread('Databases/uminhopiepreal_int01_testrss.csv');
database_P1.trainingLabels  = dlmread('Databases/uminhopiepreal_int01_trainpos.csv');
database_P1.testLabels      = dlmread('Databases/uminhopiepreal_int01_testpos.csv');

results_P1 = knn(database_P1,[]);
statistics_P1 = getStatistics( results_P1.prediction, results_P1.targets);

% Obtaining results for Interface 2
database_P2.trainingMacs    = dlmread('Databases/uminhopiepreal_int02_trainrss.csv');
database_P2.testMacs        = dlmread('Databases/uminhopiepreal_int02_testrss.csv');
database_P2.trainingLabels  = dlmread('Databases/uminhopiepreal_int02_trainpos.csv');
database_P2.testLabels      = dlmread('Databases/uminhopiepreal_int02_testpos.csv');

results_P2 = knn(database_P2,[]);
statistics_P2 = getStatistics( results_P2.prediction, results_P2.targets);

% Obtaining results for Interface 3
database_P3.trainingMacs    = dlmread('Databases/uminhopiepreal_int03_trainrss.csv');
database_P3.testMacs        = dlmread('Databases/uminhopiepreal_int03_testrss.csv');
database_P3.trainingLabels  = dlmread('Databases/uminhopiepreal_int03_trainpos.csv');
database_P3.testLabels      = dlmread('Databases/uminhopiepreal_int03_testpos.csv');

results_P3 = knn(database_P3,[]);
statistics_P3 = getStatistics( results_P3.prediction, results_P3.targets);
	
% Obtaining results for Interface 4
database_P4.trainingMacs    = dlmread('Databases/uminhopiepreal_int04_trainrss.csv');
database_P4.testMacs        = dlmread('Databases/uminhopiepreal_int04_testrss.csv');
database_P4.trainingLabels  = dlmread('Databases/uminhopiepreal_int04_trainpos.csv');
database_P4.testLabels      = dlmread('Databases/uminhopiepreal_int04_testpos.csv');

results_P4 = knn(database_P4,[]);
statistics_P4 = getStatistics( results_P4.prediction, results_P4.targets);

% Obtaining results for Interface 5
database_P5.trainingMacs    = dlmread('Databases/uminhopiepreal_int05_trainrss.csv');
database_P5.testMacs        = dlmread('Databases/uminhopiepreal_int05_testrss.csv');
database_P5.trainingLabels  = dlmread('Databases/uminhopiepreal_int05_trainpos.csv');
database_P5.testLabels      = dlmread('Databases/uminhopiepreal_int05_testpos.csv');

results_P5 = knn(database_P5,[]);
statistics_P5 = getStatistics( results_P5.prediction, results_P5.targets);

% Obtaining results for Merging Interfaces 1 to 5
database_Merge.trainingMacs    = (database_P1.trainingMacs+database_P2.trainingMacs+database_P3.trainingMacs+database_P4.trainingMacs+database_P5.trainingMacs)./5;
database_Merge.testMacs        = (database_P1.testMacs+database_P2.testMacs+database_P3.testMacs+database_P4.testMacs+database_P5.testMacs)./5;
database_Merge.trainingLabels  = database_P1.trainingLabels;
database_Merge.testLabels      = database_P1.testLabels;

results_Merge = knn(database_Merge,[]);
statistics_Merge = getStatistics( results_Merge.prediction, results_Merge.targets);


% Print all results
fprintf('P1'); fprintf('\t %5.2f ',mean(statistics_P1,1));fprintf('\n')
fprintf('P2'); fprintf('\t %5.2f ',mean(statistics_P2,1));fprintf('\n')
fprintf('P3'); fprintf('\t %5.2f ',mean(statistics_P3,1));fprintf('\n')
fprintf('P4'); fprintf('\t %5.2f ',mean(statistics_P4,1));fprintf('\n')
fprintf('P5'); fprintf('\t %5.2f ',mean(statistics_P5,1));fprintf('\n')
fprintf('Merge 5IF'); fprintf('\t %5.2f ',mean(statistics_Merge,1));fprintf('\n')

close all;
if isOctave
  pkg load nan
  cdfplot(results_P1.error); hold on
  cdfplot(results_P2.error); hold on
  cdfplot(results_P3.error); hold on
  cdfplot(results_P4.error); hold on
  cdfplot(results_P5.error); hold on
  cdfplot(results_Merge.error); hold on
  pkg unload nan
else
  cdfplot(results_P1.error); hold on
  cdfplot(results_P2.error); hold on
  cdfplot(results_P3.error); hold on
  cdfplot(results_P4.error); hold on
  cdfplot(results_P5.error); hold on
  cdfplot(results_Merge.error); hold on
end
xlabel('Positioning Error (m)')
ylabel('Cumulative Empirical Probability')
legend({'Int 1','Int 2','Int 3','Int 4','Int 5','Merged',})
print('cdf_allmodels','-dpdf')




	