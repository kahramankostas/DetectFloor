This package contains a real dataset collected by means of multiple synchronized interfaces


Overview:

    This dataset was collected within the context of a research project aiming to develop an indoor positioning system for autonomous industrial vehicles. This positioning system is based on fusing data from Wi-Fi sensors, magnetic encoders, and an IMU, using a particle filter. Wi-Fi data is first processed using Wi-Fi fingerprinting.

    One of the unique characteristics of this system is that it uses Wi-Fi fingerprints collected simultaneously from multiple, synchronised, Wi-Fi interfaces. Some results about the benefits of using multiple Wi-Fi interfaces are described in:

        Moreira, A., Silva, I., Meneses, F., Nicolau, M. J., Pendao, C., & Torres-Sospedra,  J. (2017, September). Multiple simultaneous Wi-Fi measurements in fingerprinting indoor positioning. In 2017 International Conference on Indoor Positioning and Indoor Navigation (IPIN) (pp. 1-8). IEEE. http://dx.doi.org/10.1109/IPIN.2017.8115914

    These data were collected at a university building that resembles an industrial floor plant, with a total area of around 1000 m2. The data were collected in July 2017.

    The data collection setup was based on a Raspberry Pi 3 Model B with its internal Wi-Fi interface, and four additional USB Wi-Fi interfaces (Edimax EW-7811un).


Contents:

    Databases directory:

        Contains 5 sets of files (Comma-Separated Value format), one for each one of the Wi-Fi interfaces. Each set, for interface x, includes:
        - file uminhopiepreal_int0x_testpos.csv: x,y coordinates where test fingerprints were collected; the unit is the meter;
        - file uminhopiepreal_int0x_testrss.csv: one test fingerprint per line, with the measured RSS values for each observed Access Point (AP);
        - file uminhopiepreal_int0x_trainpos.csv: x,y coordinates where training fingerprints were collected; the unit is the meter; 
        - file uminhopiepreal_int0x_trainrss.csv: one training fingerprint per line, with the measured RSS values for each observed Access Point (AP).
        
        Interface 01 is the internal interface of the Raspberry Pi. Interfaces 02 to 05 are the external USB interfaces. The dataset includes a total of 4973 training samples per interface, plus a total of 810 testing samples per interface.

    STEP01_run_all_models.m:

        This script runs all the models with the 5 independent interfaces witouth averaging  the rss values and averaging them

    knn.m:

        This function runs the IPS based on KNN model and returns a structure with the results, predictions, errors and other statistics 

    getStatistics.m:

        This function processes the results provided by knn.m and returns the average error, the median error, the 95 percentile, the 99 percentile and the maximum error.


Please, cite the following works when using the datasets included in this package:

    Moreira A. et al:  Wi-Fi Fingerprinting Dataset with Multiple Simultaneous Interfaces, Zenodo 2019   http://dx.doi.org/10.5281/zenodo.3342526

    Moreira, A., Silva, I., Meneses, F., Nicolau, M. J., Pendao, C., & Torres-Sospedra,  J. (2017, September). Multiple simultaneous Wi-Fi measurements in fingerprinting indoor positioning. In 2017 International Conference on Indoor Positioning and Indoor Navigation (IPIN) (pp. 1-8). IEEE. http://dx.doi.org/10.1109/IPIN.2017.8115914

    Check the full citation policy at http://dx.doi.org/10.5281/zenodo.3342526


For any further question about the database, please contact:

    Adriano Moreira (adriano@dsi.uminho.pt)

    
Acknowledgements:

    This work has been supported by COMPETE: POCI-01-0145-FEDER-007043 and FCT—Fundação para a Ciência e Tecnologia within the scope of project UID/CEC/00319/2019, by the Portugal Incentive System for Research and Technological Development in the scope of projects in co-promotion no 002814/2015 (iFACTORY 2015-2018).

    