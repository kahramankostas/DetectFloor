function [ statistics ] = getStatistics( predictions , targets  )


error = sqrt(sum((predictions - targets).^2,2));

meanerror   = mean(error);
medianerror = median(error);
prctile95   = prctile(error,95);
prctile99   = prctile(error,99);
maxerror    = max(error);

statistics =  [meanerror,medianerror,prctile95,prctile99,maxerror] ;

end
