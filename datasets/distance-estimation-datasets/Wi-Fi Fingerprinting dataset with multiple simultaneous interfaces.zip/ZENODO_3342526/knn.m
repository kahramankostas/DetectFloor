function [ output ] = knn( database , configuration , distanceFP )

if nargin == 2
    distanceFP = 'manhattan';
end

if size(configuration,1) == 0
    configuration.k        = 3;
    configuration.phase    = 1;
    configuration.datarep  = 'positive_150';
end

rsamples = size(database.trainingMacs,1);
osamples = size(database.testMacs,1);

output.error      = zeros(osamples,1);
output.prediction = zeros(osamples,2);
output.targets    = zeros(osamples,2);
output.candidates = zeros(osamples,1);
output.distances = zeros(osamples,1);

for i = 1:osamples
    
    ofp = database.testMacs(i,:);
    
    if     strcmp(distanceFP,'euclidean');  distances = sqrt(sum((ones(rsamples,1)*ofp - database.trainingMacs).^2,2));
    elseif strcmp(distanceFP,'manhattan');  distances = sum(abs( ones(rsamples,1)*ofp - database.trainingMacs),2);
    end
    
    [distancessort,candidates] = sort(distances);
    
    ncandidates = configuration.k;
    while ncandidates < rsamples
        if abs(distancessort(ncandidates)-distancessort(ncandidates+1))<0.000000000001
            ncandidates = ncandidates+1;
        else
            break
        end
    end
    
    point = mean(database.trainingLabels(candidates(1:ncandidates),:),1);
    output.error(i,1) = sqrt(sum((database.testLabels(i,1:2)-point).^2));
    output.prediction(i,:) = point;
    output.targets(i,:)    = database.testLabels(i,1:2);
    output.candidates(i,1) = ncandidates;
    output.distances(i,1) = distancessort(1);
    
end

